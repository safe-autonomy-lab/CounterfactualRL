from simglucose.simulation.env import T1DSimEnv as _T1DSimEnv
from simglucose.patient.t1dpatient import T1DPatient
from simglucose.sensor.cgm import CGMSensor
from simglucose.actuator.pump import InsulinPump
from simglucose.simulation.scenario_gen import RandomScenario
from simglucose.simulation.scenario import CustomScenario
from simglucose.controller.base import Action
import numpy as np
import pkg_resources
import gym
from gym import spaces
from gym.utils import seeding
from datetime import datetime

PATIENT_PARA_FILE = pkg_resources.resource_filename(
    'simglucose', 'params/vpatient_params.csv')


class T1DSimEnv(gym.Env):
    '''
    A wrapper of simglucose.simulation.env.T1DSimEnv to support gym API
    '''
    metadata = {'render.modes': ['human']}

    SENSOR_HARDWARE = 'Dexcom'
    INSULIN_PUMP_HARDWARE = 'Insulet'

    def __init__(self, patient_name=None, custom_scenario_id=0, reward_fun=None, seed=None):
        '''
        patient_name must be 'adolescent#001' to 'adolescent#010',
        or 'adult#001' to 'adult#010', or 'child#001' to 'child#010'
        '''
        # have to hard code the patient_name, gym has some interesting
        # error when choosing the patient
        if patient_name is None:
            patient_name = 'adolescent#001'
        self.patient_name = patient_name
        self.reward_fun = reward_fun
        self.np_random, _ = seeding.np_random(seed=seed)
        self.custom_scenario_list = [[(496, 40), (778, 84), (1097, 69)], [(422, 44), (540, 7), (750, 74), (1135, 82), (1224, 5)],
                                    [(390, 42), (1113, 85), (1265, 8)], [(421, 49), (563, 12), (762, 54), (1086, 78), (1299, 3)],
                                    [(369, 51), (705, 54), (1060, 78)], [(531, 38), (691, 67), (1043, 89)],
                                    [(533, 47), (544, 15), (649, 76), (1147, 71), (1289, 13)], [(359, 44), (724, 79), (1031, 81)],
                                    [(407, 29), (710, 74), (1122, 86)], [(472, 66), (767, 66), (1121, 75)]]
        self.cust_scen_index = custom_scenario_id#np.random.randint(low=0, high=len(self.custom_scenario_list))
        #self.assigned_init_bg_value_interval=assigned_init_bg_value_interval
        hour = self.np_random.randint(low=0.0, high=24.0)
        start_time = datetime(2022, 1, 1, hour, 0, 0)
        custom_scenario = CustomScenario(start_time=start_time, scenario=self.custom_scenario_list[self.cust_scen_index]) # choose from fixed meal plans to run the simulation
        # {'meal': {'time': [496.0, 778.0, 1097.0], 'amount': [40.0, 84.0, 69.0]}}
        # {'meal': {'time': [422.0, 540.0, 750.0, 1135.0, 1224.0], 'amount': [44.0, 7.0, 74.0, 82.0, 5.0]}}
        # {'meal': {'time': [390.0, 1113.0, 1265.0], 'amount': [42.0, 85.0, 8.0]}}
        # {'meal': {'time': [421.0, 563.0, 762.0, 1086.0, 1299.0], 'amount': [49.0, 12.0, 54.0, 78.0, 3.0]}}
        # {'meal': {'time': [369.0, 705.0, 1060.0], 'amount': [51.0, 54.0, 78.0]}}
        # {'meal': {'time': [531.0, 691.0, 1043.0], 'amount': [38.0, 67.0, 89.0]}}
        # {'meal': {'time': [533.0, 544.0, 649.0, 1147.0, 1289.0], 'amount': [47.0, 15.0, 76.0, 71.0, 13.0]}}
        # {'meal': {'time': [359.0, 724.0, 1031.0], 'amount': [44.0, 79.0, 81.0]}}
        # {'meal': {'time': [407.0, 710.0, 1122.0], 'amount': [29.0, 74.0, 86.0]}}
        # {'meal': {'time': [472.0, 767.0, 1121.0], 'amount': [66.0, 66.0, 75.0]}}
        self.env, _, _, _ = self._create_env_from_random_state(custom_scenario)

    def _step(self, action):
        # This gym only controls basal insulin
        act = Action(basal=action, bolus=0)
        if self.reward_fun is None:
            return self.env.step(act)
        return self.env.step(act, reward_fun=self.reward_fun)

    def _reset(self, **kwargs):
        #print('_reset in simglucose_gym_env.')
        #patient_kwargs = kwargs['patient_state']
        self.custom_scenario_list = [[(496, 40), (778, 84), (1097, 69)],
                                     [(422, 44), (540, 7), (750, 74), (1135, 82), (1224, 5)],
                                     [(390, 42), (1113, 85), (1265, 8)],
                                     [(421, 49), (563, 12), (762, 54), (1086, 78), (1299, 3)],
                                     [(369, 51), (705, 54), (1060, 78)],
                                     [(531, 38), (691, 67), (1043, 89)],
                                     [(533, 47), (544, 15), (649, 76), (1147, 71), (1289, 13)],
                                     [(359, 44), (724, 79), (1031, 81)],
                                     [(407, 29), (710, 74), (1122, 86)],
                                     [(472, 66), (767, 66), (1121, 75)]]
        #cust_scen_index = np.random.randint(low=0, high=len(self.custom_scenario_list))
        hour = self.np_random.randint(low=0.0, high=24.0)
        start_time = datetime(2022, 1, 1, hour, 0, 0)
        custom_scenario = CustomScenario(start_time=start_time, scenario=self.custom_scenario_list[self.cust_scen_index])  # choose from fixed meal plans to run the simulation
        self.env, _, _, _ = self._create_env_from_random_state(custom_scenario=custom_scenario)
        #self.env, _, _, _ = self._create_env_from_random_state()
        obs, _, _, _ = self.env.reset(**kwargs)
        return obs

    def _seed(self, seed=None):
        self.np_random, seed1 = seeding.np_random(seed=seed)
        self.env, seed2, seed3, seed4 = self._create_env_from_random_state()
        return [seed1, seed2, seed3, seed4]

    def _create_env_from_random_state(self, custom_scenario=None):
        # Derive a random seed. This gets passed as a uint, but gets
        # checked as an int elsewhere, so we need to keep it below
        # 2**31.
        #print('_create_env_from_random_state.')
        seed2 = seeding.hash_seed(self.np_random.randint(0, 1000)) % 2**31
        seed3 = seeding.hash_seed(seed2 + 1) % 2**31
        seed4 = seeding.hash_seed(seed3 + 1) % 2**31

        hour = self.np_random.randint(low=0.0, high=24.0)
        start_time = datetime(2022, 1, 1, hour, 0, 0)
        patient = T1DPatient.withName(self.patient_name, random_init_bg=True, seed=seed4)
        #print('patient: ', patient)
        sensor = CGMSensor.withName(self.SENSOR_HARDWARE, seed=seed2)
        #print('sensor: ', sensor)
        scenario = RandomScenario(start_time=start_time, seed=seed3) if custom_scenario is None else custom_scenario
        #print('scenario: ', scenario)
        pump = InsulinPump.withName(self.INSULIN_PUMP_HARDWARE)
        #print('pump: ', pump)
        env = _T1DSimEnv(patient, sensor, pump, scenario)
        return env, seed2, seed3, seed4

    def _render(self, mode='human', close=False):
        self.env.render(close=close)

    @property
    def action_space(self):
        #ub = self.env.pump._params['max_basal']
        ub = 1.5
        return spaces.Box(low=0, high=ub, shape=(1,))

    @property
    def observation_space(self):
        #return spaces.Box(low=0, high=np.inf, shape=(1,))
        if self.env.if_stlu ==1:
            return spaces.Box(low=0, high=np.inf, shape=(6,))
        else:
            return spaces.Box(low=0, high=np.inf, shape=(4,))

