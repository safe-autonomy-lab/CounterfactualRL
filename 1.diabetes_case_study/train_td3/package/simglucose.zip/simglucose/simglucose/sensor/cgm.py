# from .noise_gen import CGMNoiseGenerator
from .noise_gen import CGMNoise
import pandas as pd
import logging
import pkg_resources

logger = logging.getLogger(__name__)
SENSOR_PARA_FILE = pkg_resources.resource_filename(
    'simglucose', 'params/sensor_params.csv')


class CGMSensor(object):
    def __init__(self, params, seed=None):
        self._params = params
        self.name = params.Name
        self.sample_time = params.sample_time
        self.seed = seed
        self._last_CGM = 0

    @classmethod
    def withName(cls, name, **kwargs):
        sensor_params = pd.read_csv(SENSOR_PARA_FILE)
        params = sensor_params.loc[sensor_params.Name == name].squeeze()
        return cls(params, **kwargs)

    def measure(self, patient, CGM_value=0, determain=0):
        #print('patient.t: ', patient.t, type(patient.t))
        if patient.t % self.sample_time == 0:
            if determain==0:
                BG = patient.observation.Gsub
                CGM = BG + next(self._noise_generator)
                #print('In CGM.py BG: ', BG, ' CGM: ', CGM)
                CGM = max(CGM, self._params["min"])
                CGM = min(CGM, self._params["max"])
                self._last_CGM = CGM
                #print('CGM after change: ', CGM)
            elif determain==1:
                CGM = CGM_value
                self._last_CGM = CGM
                # print('CGM after change: ', CGM)

            return CGM

        # Zero-Order Hold
        return self._last_CGM

    @property
    def seed(self):
        return self._seed

    @seed.setter
    def seed(self, seed):
        self._seed = seed
        self._noise_generator = CGMNoise(self._params, seed=seed)

    def reset(self, **kwargs):
        #print('sensor reset.')
        # print('kwargs: ', kwargs)
        dict = kwargs
        # print(type(dict))
        if (not ('determine' in dict.keys())) or dict['determine'] == 0:  # if do not need to use deterministic reset.
            logger.debug('Resetting CGM sensor ...')
            self._noise_generator = CGMNoise(self._params, seed=self.seed)
            self._last_CGM = 0
        elif dict['determine'] == 1:  # if need to use deterministic reset to set patient state to some specific values
            #print('dict: ', dict['sensor_params'].tolist()[0], type(dict['sensor_params'].tolist()[0]))
            logger.debug('Resetting CGM sensor determine ...')
            #self._params = dict['sensor_params']
            #print('Input sensor param: ', dict['sensor_params'])
            self.seed = dict['sensor_seed']
            #print('self.seed: ', self.seed)
            #print('self._params: ', self._params)
            self._noise_generator = CGMNoise(self._params, seed=self.seed)
            self._last_CGM = dict['sensor_last_cgm']
            # print('AFTER DETERMINISTIC RESET SENSOR.')
            # print('self._params: ', self._params)
            # print('self.seed: ', self.seed)
            # print('self._last_CGM: ', self._last_CGM)



if __name__ == '__main__':
    pass
