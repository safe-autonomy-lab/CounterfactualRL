import logging
import time
import os
import pandas as pd
import torch
import numpy as numpy
## PyTorch
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.utils.data as data
import torch.optim as optim
from torch.autograd import Variable
import torch._VF as _VF
import sys
# import STL-U monitor
STLU_path = '/content/drive/MyDrive/ColabNotebooks/Medical_case/stlu_monitor'
sys.path.append(STLU_path)
import ustlmonitor as ustl
import confidencelevel
from collections import namedtuple
from scipy.stats import norm

pathos = True
try:
    from pathos.multiprocessing import ProcessPool as Pool
except ImportError:
    print('You could install pathos to enable parallel simulation.')
    pathos = False

Observation = namedtuple('Observation', ['CGM'])
logger = logging.getLogger(__name__)


class SimObj(object):
    def __init__(self,
                 env,
                 controller,
                 sim_time,
                 lstm_model,
                 requirement_func,
                 animate=True,
                 path=None):
        self.env = env
        self.controller = controller
        self.sim_time = sim_time
        self.animate = animate
        self._ctrller_kwargs = None
        self.path = path
        self.lstm_model = lstm_model
        self.requirement_func=requirement_func
    # convert history df
    def get_patient_trace(self, history_df, rho_set_CGM_list, predicted_CGM_mean_list, predicted_CGM_std_list, predicted_CGM_up_list, 
              predicted_CGM_low_list, if_warning_this_step_list,if_warning_eat_this_step_list, current_state_list,
              basal_severe_low_adjust_list,basal_severe_high_not_last_adjust_list,basal_severe_high_last_adjust_list,
              basal_mild_low_not_last_adjust_list,basal_mild_low_last_adjust_list,basal_mild_high_not_last_adjust_list,
              basal_mild_high_last_adjust_list,bolus_correction_adjust_list,meal_bolus_adjust_list, 
              basal_amount_list, correction_bolus_amount_list, meal_bolus_amount_list, max_total_bolus_trigger_flag_list):
      selected_feature_col = ['hour', 'minute', 'LBGI', 'HBGI', 'Risk',
                    'rho_set_CGM' , 'predicted_CGM_mean','predicted_CGM_up','predicted_CGM_low','predicted_CGM_std','BG',
                    'CGM', 'CHO', 'insulin', 'if_warning_this_step','if_warning_eat_this_step','current_state',
                    'basal_severe_low_adjust','basal_severe_high_not_last_adjust','basal_severe_high_last_adjust', 
                    'basal_mild_low_not_last_adjust','basal_mild_low_last_adjust',
                    'basal_mild_high_not_last_adjust','basal_mild_high_last_adjust','bolus_correction_adjust',
                    'meal_bolus_adjust', 'basal', 'correction_bolus', 'meal_bolus','max_total_bolus_trigger_flag']
      patient_trace_df = pd.DataFrame(columns=selected_feature_col)
      # change time format, save hour and minute
      hour_list = []
      minute_list = []
      time_list = []
      delta_cgm_list = []
      for item, row in history_df.iterrows():
        time_str = item
        hour = item.hour
        minute = item.minute
        time = time_str 
        time_list.append(time)
        hour_list.append(hour)
        minute_list.append(minute)
      patient_trace_df['hour'] = hour_list
      patient_trace_df['minute'] = minute_list
      patient_trace_df['rho_set_CGM'] = rho_set_CGM_list
      patient_trace_df['predicted_CGM_mean'] = predicted_CGM_mean_list
      patient_trace_df['predicted_CGM_up'] = predicted_CGM_up_list
      patient_trace_df['predicted_CGM_low'] = predicted_CGM_low_list
      patient_trace_df['predicted_CGM_std'] = predicted_CGM_std_list
      patient_trace_df['if_warning_this_step'] = if_warning_this_step_list
      patient_trace_df['if_warning_eat_this_step'] = if_warning_eat_this_step_list
      patient_trace_df['basal_severe_low_adjust'] = basal_severe_low_adjust_list
      patient_trace_df['basal_severe_high_not_last_adjust'] = basal_severe_high_not_last_adjust_list
      patient_trace_df['basal_severe_high_last_adjust'] = basal_severe_high_last_adjust_list
      patient_trace_df['basal_mild_low_not_last_adjust'] = basal_mild_low_not_last_adjust_list
      patient_trace_df['basal_mild_low_last_adjust'] = basal_mild_low_last_adjust_list
      patient_trace_df['basal_mild_high_not_last_adjust'] = basal_mild_high_not_last_adjust_list
      patient_trace_df['basal_mild_high_last_adjust'] = basal_mild_high_last_adjust_list
      patient_trace_df['bolus_correction_adjust']=bolus_correction_adjust_list
      patient_trace_df['meal_bolus_adjust']=meal_bolus_adjust_list
      patient_trace_df['max_total_bolus_trigger_flag']=max_total_bolus_trigger_flag_list

      patient_trace_df['basal'] = basal_amount_list
      patient_trace_df['correction_bolus']=correction_bolus_amount_list
      patient_trace_df['meal_bolus']=meal_bolus_amount_list

      patient_trace_df['LBGI'] = history_df['LBGI'].to_list()
      patient_trace_df['Risk'] = history_df['Risk'].to_list()
      patient_trace_df['HBGI'] = history_df['HBGI'].to_list()
      patient_trace_df['CGM'] = history_df['CGM'].to_list()
      patient_trace_df['BG'] = history_df['BG'].to_list()
      history_cho_list = history_df['CHO'].to_list()
      history_cho_list[-1] = history_cho_list[-2] if len(history_cho_list)!=1 else history_cho_list[-1]
      history_insulin_list = history_df['insulin'].to_list()
      history_insulin_list[-1] = history_insulin_list[-2] if len(history_insulin_list)!=1 else history_insulin_list[-1]
      history_state_list = current_state_list
      patient_trace_df['CHO'] = history_cho_list
      patient_trace_df['insulin'] = history_insulin_list
      patient_trace_df['current_state'] = history_state_list
      return patient_trace_df
    # get upper and lower bound for predicted flowpipe
    def get_upper_lower_bound_flowpipe(self, mean, sigma, conf):
      # calculate upper and lower bound using given mean, std, and conf
      p = 1 - (1 - conf) / 2
      lower = mean - norm.ppf(p) * sigma # norm.ppf(p):get the x value for certain confidence level p
      upper = mean + norm.ppf(p) * sigma
      return (lower, upper)
    # predict single trace with trained lstm
    def predict_with_lstm_with_dropout(self, dataset_loader, lstm_model, device, batch_size, predict_length, hidden_size, N_MC, 
                step_look_back, dropout_rate, dropout_type, requirement_func, mean_df, std_df, conf):
      # evaluate the trained model with dataset
      lstm_model.eval()
      batch_len=1
      with torch.no_grad():
        for batch_idx, datasample in enumerate(dataset_loader):  # tqdm(enumerate(test_loader)):
            data,target0 = datasample[0], datasample[1]
            target = []
            output = torch.zeros(N_MC, batch_len, predict_length, hidden_size)
            # apply dropout and loop N_MC times to get a series of predicted traces
            new_mean_df = mean_df.reset_index(drop=True)
            new_std_df = std_df.reset_index(drop=True)
            for i in range(N_MC):
                output[i] = (lstm_model.forward_test_with_past(data, step_look_back, hidden_size, dropout_rate, dropout_type)).cpu()
                # change predictions back to original scale
                for feature_index in range(output[i].shape[2]):
                  output[i][:, :, feature_index] = (output[i][:, :, feature_index]*new_std_df.loc[feature_index]+new_mean_df.loc[feature_index]).cpu()
            output_CGM_mean = output.mean(dim=0)[:, :, -3]
            output_CGM_std = output.std(dim=0)[:, :, -3]
            trace_CGM = torch.stack((output_CGM_mean, output_CGM_std), dim=-1)
            # record mean and std value for each sample after applying dropout and loop N_MC times
            for b in range(batch_len):
                # get rho interval for predictions with STL-U
                rho_set_CGM = requirement_func(trace_CGM[b, :, :], predict_length-1, conf=conf, lower_BG=70, upper_BG=180, func='monitor')
        return output_CGM_mean.squeeze(0), output_CGM_std.squeeze(0), rho_set_CGM

    def simulate(self, patient_trace_path, t_history, mean_df, std_df, dropout_rate, dropout_type, conf, N_MC, lstm_type='lstm_with_monitor'):
        self.controller.reset()
        obs, reward, done, info = self.env.reset()
        tic = time.time()
        all_feature_col = ['hour', 'minute', 'LBGI', 'HBGI', 'Risk', 
                    'rho_set_CGM' , 'predicted_CGM_mean','predicted_CGM_up','predicted_CGM_low','predicted_CGM_std','BG',
                    'CGM', 'CHO', 'insulin', 'if_warning_this_step','if_warning_eat_this_step','current_state',
                    'basal_severe_low_adjust','basal_severe_high_not_last_adjust','basal_severe_high_last_adjust', 
                    'basal_mild_low_not_last_adjust','basal_mild_low_last_adjust',
                    'basal_mild_high_not_last_adjust','basal_mild_high_last_adjust','bolus_correction_adjust',
                    'meal_bolus_adjust', 'basal', 'correction_bolus', 'meal_bolus', 'max_total_bolus_trigger_flag']
        selected_feature_col = ['hour', 'minute', 'LBGI', 'HBGI', 'Risk', 'CGM', 'CHO', 'insulin']
        patient_trace_df = pd.DataFrame(columns=all_feature_col)
        patient_trace_selected_df = pd.DataFrame(columns=selected_feature_col)
        rho_set_CGM_list = []
        predicted_CGM_mean_list = []
        predicted_CGM_std_list = []
        predicted_CGM_up_list = []
        predicted_CGM_low_list = []
        if_warning_this_step_list = []
        if_warning_eat_this_step_list = []
        # list for saving basal adjust marker
        basal_severe_low_adjust_list = []
        basal_severe_high_not_last_adjust_list = []
        basal_severe_high_last_adjust_list = []
        basal_mild_low_not_last_adjust_list = []
        basal_mild_low_last_adjust_list = []
        basal_mild_high_not_last_adjust_list = []
        basal_mild_high_last_adjust_list = []
        bolus_correction_adjust_list = []
        meal_bolus_adjust_list = []
        basal_amount_list = []
        correction_bolus_amount_list = []
        meal_bolus_amount_list = []
        max_total_bolus_trigger_flag_list = []
        current_state_list = []
        hidden_size = len(selected_feature_col)
        step_look_back = 10 # 10 step for historical 30min trace
        predict_length = 10 # 10 step for future 30min trace
        device = torch.device("cpu")
        batch_size = 1
        time_step_count = 0
        # save reset info
        current_CGM = obs.CGM # real cgm from env
        current_hour = info['time'].hour
        current_min = info['time'].minute
        #current_cho = info['meal']
        current_hbgi = info['hbgi']
        current_lbgi = info['lbgi']
        current_risk = info['risk']
        current_warning = 0
        current_rho_set_CGM = [0,0]
        current_predict_CGM_mean = torch.Tensor([0]*predict_length) 
        current_predict_CGM_std = torch.Tensor([0]*predict_length)
        current_predict_CGM_up = torch.Tensor([0]*predict_length) # upper value trace for current prediction 
        current_predict_CGM_low = torch.Tensor([0]*predict_length) # lower value trace for current prediction 
        #
        while self.env.time < self.env.scenario.start_time + self.sim_time:
            if self.animate:
                self.env.render()
            #print('time_step_count: ', time_step_count, ' self.env.time: ', self.env.time)
            if time_step_count<t_history or lstm_type=='no_lstm':
              self.controller.trace_type='history'
              # generate 1h trace with normal control(same as BB controller) for future prediction
              sample_time = info.get('sample_time', 1)
              pname = info.get('patient_name')
              meal = info.get('meal')  # unit: g/min
              current_cho = meal
              #if time_step_count>=20:
              action, if_warning_this_step,if_warning_eat_this_step,basal_adjust_mark_dict,(basal, correction_bolus, meal_bolus, max_total_bolus_trigger_flag) = self.controller._bb_policy(pname, meal, obs, sample_time, current_state_from_main_controller=0)
              # save trace
              current_warning = if_warning_this_step
              current_warning_eat = if_warning_eat_this_step
              if_warning_this_step_list.append(current_warning)
              if_warning_eat_this_step_list.append(current_warning_eat)
              basal_amount_list.append(basal)
              correction_bolus_amount_list.append(correction_bolus)
              meal_bolus_amount_list.append(meal_bolus)
              max_total_bolus_trigger_flag_list.append(max_total_bolus_trigger_flag)
              # save basal/bolus adjust marker
              basal_severe_low_adjust_list.append(basal_adjust_mark_dict['basal_severe_low_adjust'])
              basal_severe_high_not_last_adjust_list.append(basal_adjust_mark_dict['basal_severe_high_not_last_adjust'])
              basal_severe_high_last_adjust_list.append(basal_adjust_mark_dict['basal_severe_high_last_adjust'])
              basal_mild_low_not_last_adjust_list.append(basal_adjust_mark_dict['basal_mild_low_not_last_adjust'])
              basal_mild_low_last_adjust_list.append(basal_adjust_mark_dict['basal_mild_low_last_adjust'])
              basal_mild_high_not_last_adjust_list.append(basal_adjust_mark_dict['basal_mild_high_not_last_adjust'])
              basal_mild_high_last_adjust_list.append(basal_adjust_mark_dict['basal_mild_high_last_adjust'])
              bolus_correction_adjust_list.append(basal_adjust_mark_dict['bolus_correction_adjust'])
              meal_bolus_adjust_list.append(basal_adjust_mark_dict['meal_bolus_adjust'])
              #
              rho_set_CGM_list.append(current_rho_set_CGM)
              predicted_CGM_mean_list.append(current_predict_CGM_mean.numpy().tolist())
              predicted_CGM_std_list.append(current_predict_CGM_std.numpy().tolist())
              predicted_CGM_up_list.append(current_predict_CGM_up.numpy().tolist())
              predicted_CGM_low_list.append(current_predict_CGM_low.numpy().tolist())
              current_state_list = self.controller.state_list

              patient_trace_df = self.get_patient_trace(self.env.show_history(), rho_set_CGM_list, predicted_CGM_mean_list, 
                            predicted_CGM_std_list, predicted_CGM_up_list, predicted_CGM_low_list,
                            if_warning_this_step_list,if_warning_eat_this_step_list, current_state_list,
                            basal_severe_low_adjust_list,
                            basal_severe_high_not_last_adjust_list,
                            basal_severe_high_last_adjust_list,
                            basal_mild_low_not_last_adjust_list,
                            basal_mild_low_last_adjust_list,
                            basal_mild_high_not_last_adjust_list,
                            basal_mild_high_last_adjust_list,bolus_correction_adjust_list,meal_bolus_adjust_list, 
                            basal_amount_list, correction_bolus_amount_list, meal_bolus_amount_list,max_total_bolus_trigger_flag_list)
              patient_trace_selected_df = pd.DataFrame(patient_trace_df, columns=selected_feature_col)

              obs, reward, done, info = self.env.step(action)
              rho_set_CGM = [0,0]
              output_CGM_mean = torch.Tensor([0]*predict_length)
              output_CGM_std = torch.Tensor([0]*predict_length)
              output_CGM_up = torch.Tensor([0]*predict_length)
              output_CGM_low = torch.Tensor([0]*predict_length)

            else:
              # get last 10 step trace, used as historical data for prediction
              past_df_x = patient_trace_selected_df[-predict_length:]
              past_df_y = patient_trace_selected_df[-predict_length-1:-1]
              # standardlize
              new_mean_df = mean_df
              new_std_df = std_df
              for feature in selected_feature_col:
                  a_x = past_df_x[feature]-new_mean_df.loc[feature]
                  b_x = a_x/new_std_df.loc[feature]
                  a_y = past_df_x[feature]-new_mean_df.loc[feature]
                  b_y = a_x/new_std_df.loc[feature]
                  past_df_x[feature] = b_x
                  past_df_y[feature] = b_y
              x = numpy.array(past_df_x)
              y = numpy.array(past_df_y)
              x = numpy.concatenate((x, numpy.zeros((predict_length, len(selected_feature_col)))), axis=0)
              y = numpy.concatenate((y, numpy.zeros((predict_length, len(selected_feature_col)))), axis=0)
              dataX = Variable(torch.from_numpy(x))
              dataY = Variable(torch.from_numpy(y))
              dataX = dataX.unsqueeze(0)
              dataY = dataY.unsqueeze(0)
              testX = Variable(torch.Tensor(numpy.array(dataX)))
              testY = Variable(torch.Tensor(numpy.array(dataY)))
              test_set = torch.utils.data.TensorDataset(testX,testY)
              test_loader = torch.utils.data.DataLoader(test_set, batch_size=1, num_workers=0, shuffle=False)
              # get mean value trace, std trace and rho interval for predicted flowpipe
              if lstm_type=='lstm_with_monitor':
                self.controller.trace_type='future'
                # connect lstm with STL-U, using monitor results for self-defined controller to decide action
                output_CGM_mean, output_CGM_std, rho_set_CGM = self.predict_with_lstm_with_dropout(test_loader, self.lstm_model, device, 
                                batch_size, predict_length, hidden_size, N_MC, 
                                step_look_back, dropout_rate, dropout_type, 
                                self.requirement_func, new_mean_df, new_std_df, conf)
                output_CGM_low, output_CGM_up = self.get_upper_lower_bound_flowpipe(output_CGM_mean, output_CGM_std, conf)
                obs_real = obs  # real observation from env
                action, if_warning_this_step,if_warning_eat_this_step,basal_adjust_mark_dict,(basal, correction_bolus, meal_bolus,max_total_bolus_trigger_flag) = self.controller.policy(patient_trace_df, rho_set_CGM, output_CGM_mean, output_CGM_std, 
                                            output_CGM_low, output_CGM_up,
                                            obs_real, reward, done, **info)
              elif lstm_type=='lstm_no_monitor':
                self.controller.trace_type='history'
                # not using monitor, pass predicted CGM to BB control policy to decide action
                '''output_CGM_mean, output_CGM_std, rho_set_CGM = self.predict_with_lstm_no_dropout(test_loader, self.lstm_model, device, 
                                batch_size, predict_length, hidden_size, N_MC, 
                                step_look_back, self.requirement_func)'''
                output_CGM_mean, output_CGM_std, rho_set_CGM = self.predict_with_lstm_with_dropout(test_loader, self.lstm_model, device, 
                                batch_size, predict_length, hidden_size, N_MC, 
                                step_look_back, dropout_rate, dropout_type, 
                                self.requirement_func, new_mean_df, new_std_df, conf)
                output_CGM_low, output_CGM_up = self.get_upper_lower_bound_flowpipe(output_CGM_mean, output_CGM_std, conf)
                sample_time = info.get('sample_time', 1)
                pname = info.get('patient_name')
                meal = info.get('meal')  # unit: g/min
                obs_predict = Observation(CGM=torch.mean(output_CGM_mean)) # need define
                action, if_warning_this_step,if_warning_eat_this_step,basal_adjust_mark_dict,(basal, correction_bolus, meal_bolus) = self.controller._bb_policy(pname, meal, obs_predict, sample_time, current_state_from_main_controller=0)
              # save trace
              current_rho_set_CGM = rho_set_CGM # rho interval for current prediction
              current_predict_CGM_mean = output_CGM_mean # mean value trace for current prediction 
              current_predict_CGM_std = output_CGM_std # std value trace for current prediction 
              current_predict_CGM_up = output_CGM_up # upper value trace for current prediction 
              current_predict_CGM_low = output_CGM_low # lower value trace for current prediction 
              current_warning = if_warning_this_step
              current_warning_eat = if_warning_eat_this_step
              if_warning_this_step_list.append(current_warning)
              if_warning_eat_this_step_list.append(current_warning_eat)
              basal_amount_list.append(basal)
              max_total_bolus_trigger_flag_list.append(max_total_bolus_trigger_flag)
              correction_bolus_amount_list.append(correction_bolus)
              meal_bolus_amount_list.append(meal_bolus)
              # save basal adjust marker
              basal_severe_low_adjust_list.append(basal_adjust_mark_dict['basal_severe_low_adjust'])
              basal_severe_high_not_last_adjust_list.append(basal_adjust_mark_dict['basal_severe_high_not_last_adjust'])
              basal_severe_high_last_adjust_list.append(basal_adjust_mark_dict['basal_severe_high_last_adjust'])
              basal_mild_low_not_last_adjust_list.append(basal_adjust_mark_dict['basal_mild_low_not_last_adjust'])
              basal_mild_low_last_adjust_list.append(basal_adjust_mark_dict['basal_mild_low_last_adjust'])
              basal_mild_high_not_last_adjust_list.append(basal_adjust_mark_dict['basal_mild_high_not_last_adjust'])
              basal_mild_high_last_adjust_list.append(basal_adjust_mark_dict['basal_mild_high_last_adjust'])
              bolus_correction_adjust_list.append(basal_adjust_mark_dict['bolus_correction_adjust'])
              meal_bolus_adjust_list.append(basal_adjust_mark_dict['meal_bolus_adjust'])
              #
              rho_set_CGM_list.append(current_rho_set_CGM)
              predicted_CGM_mean_list.append(current_predict_CGM_mean.numpy().tolist())
              predicted_CGM_std_list.append(current_predict_CGM_std.numpy().tolist())
              predicted_CGM_up_list.append(current_predict_CGM_up.numpy().tolist())
              predicted_CGM_low_list.append(current_predict_CGM_low.numpy().tolist())
              current_state_list = self.controller.state_list
              patient_trace_df = self.get_patient_trace(self.env.show_history(), rho_set_CGM_list, 
                          predicted_CGM_mean_list, predicted_CGM_std_list, predicted_CGM_up_list, predicted_CGM_low_list, 
                          if_warning_this_step_list,if_warning_eat_this_step_list,current_state_list,
                          basal_severe_low_adjust_list,
                            basal_severe_high_not_last_adjust_list,
                            basal_severe_high_last_adjust_list,
                            basal_mild_low_not_last_adjust_list,
                            basal_mild_low_last_adjust_list,
                            basal_mild_high_not_last_adjust_list,
                            basal_mild_high_last_adjust_list,bolus_correction_adjust_list,meal_bolus_adjust_list, 
                            basal_amount_list, correction_bolus_amount_list, meal_bolus_amount_list,max_total_bolus_trigger_flag_list
                            )
              patient_trace_selected_df = pd.DataFrame(patient_trace_df, columns=selected_feature_col)
              obs, reward, done, info = self.env.step(action)
            time_step_count += 1
        patient_trace_df.to_csv('{patient_trace_path}/patient_trace_{pname}_{lstm_type}.csv'.format(patient_trace_path=patient_trace_path,
                         pname=pname, lstm_type=lstm_type))
        toc = time.time()
        logger.info('Simulation took {} seconds.'.format(toc - tic))

    def results(self):
        return self.env.show_history()

    def save_results(self):
        df = self.results()
        if not os.path.isdir(self.path):
            os.makedirs(self.path)
        filename = os.path.join(self.path, str(self.env.patient.name) + '.csv')
        df.to_csv(filename)

    def reset(self):
        self.env.reset()
        self.controller.reset()


def sim(sim_object, patient_trace_path, t_history, mean_df, std_df, dropout_rate, dropout_type, conf, N_MC, lstm_type='with_dropout'):
    print("Process ID: {}".format(os.getpid()))
    print('Simulation starts ...')
    sim_object.simulate(patient_trace_path, t_history, mean_df, std_df, dropout_rate, dropout_type, conf, N_MC, lstm_type)
    sim_object.save_results()
    print('Simulation Completed!')
    return sim_object.results()


def batch_sim(sim_instances, parallel=False):
    tic = time.time()
    if parallel and pathos:
        with Pool() as p:
            results = p.map(sim, sim_instances)
    else:
        if parallel and not pathos:
            print('Simulation is using single process even though parallel=True.')
        results = [sim(s) for s in sim_instances]
    toc = time.time()
    print('Simulation took {} sec.'.format(toc - tic))
    return results
