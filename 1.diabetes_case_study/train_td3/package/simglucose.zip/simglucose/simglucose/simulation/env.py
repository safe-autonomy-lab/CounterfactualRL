from simglucose.patient.t1dpatient import Action
from simglucose.analysis.risk import risk_index
from simglucose.simulation.scenario import CustomScenario
import pandas as pd
from datetime import timedelta
import logging
from collections import namedtuple
from simglucose.simulation.rendering import Viewer
import time
import numpy as np
from memory_profiler import profile
from torch.autograd import Variable
try:
    from rllab.envs.base import Step
except ImportError:
    _Step = namedtuple("Step", ["observation", "reward", "done", "info"])

    def Step(observation, reward, done, **kwargs):
        """
        Convenience method creating a namedtuple with the results of the
        environment.step method.
        Put extra diagnostic info in the kwargs
        """
        return _Step(observation, reward, done, kwargs)


Observation = namedtuple('Observation', ['CGM', 'CHO', 'ROC','insulin'])
#Observation = namedtuple('Observation', ['CGM', 'CHO', 'ROC','insulin', 'rho_low', 'rho_up'])
logger = logging.getLogger(__name__)

###########################################
# parameters for LSTM and stlu
# import STL-U monitor
import sys
#STLU_path = '/p/citypm/AIFairness/Counterfactual_Explanation/stlu_monitor'
#sys.path.append(STLU_path)
#import ustlmonitor as ustl
#import confidencelevel
from scipy.stats import norm
import torch
import torch.nn as nn
import torch._VF as _VF
# lstm model for prediction
class LSTMCellWithMask(nn.LSTMCell):
    def __init__(self, input_size, hidden_size, bias=True):
        super(LSTMCellWithMask, self).__init__(input_size, hidden_size, bias=True)

    def forward_with_mask(self, input, mask, hx=None):
        (mask_ih, mask_hh) = mask
        # type: (Tensor, Optional[Tuple[Tensor, Tensor]]) -> Tuple[Tensor, Tensor]
        # self.check_forward_input(input)
        if hx is None:
            zeros = torch.zeros(input.size(0), self.hidden_size, dtype=input.dtype, device=input.device)
            hx = (zeros, zeros)
        # LSTMCell.weight_ih： [4*hidden_size, input_size]
        # LSTMCell.weight_hh [4*hidden_size, hidden_size]
        # LSTMCell.bias_ih [4*hidden_size]
        # LSTMCell.bias_hh [4*hidden_size]
        return _VF.lstm_cell(
            input, hx,
            self.weight_ih * mask_ih, self.weight_hh * mask_hh,
            self.bias_ih, self.bias_hh
        )
class LSTM(nn.Module):

    def __init__(self, num_classes, input_size, hidden_size, num_layers, step_look_back, train_dropout_type):
        super(LSTM, self).__init__()
        self.lstm = LSTMCellWithMask(input_size=input_size, hidden_size=hidden_size)
        self.linear = nn.Linear(hidden_size, num_classes)
        self.hidden_size = hidden_size
        self.train_dropout_type = train_dropout_type
        self.input_size = input_size
        self.output_size = input_size
        #print('train dropout type: ', train_dropout_type)
        # store all hyperparameters in a dictionary for saving and loading of the model
        self.config = {"input_size": self.input_size, "output_size": self.output_size, "hidden_size": self.hidden_size}

    def forward(self, input, step_look_back, hidden_size, dropout_rate):
        # funcation for train, dropout type using train_dropout_type
        outputs = []
        device = input.device
        h_t = torch.zeros(input.size(0), self.input_size, dtype=torch.float, device=device)
        c_t = torch.zeros(input.size(0), self.input_size, dtype=torch.float, device=device)

        if self.train_dropout_type == 1:
            # print('type 1: ')
            mask1 = torch.bernoulli(
                torch.ones(4 * hidden_size, self.input_size, dtype=torch.float) * dropout_rate) / dropout_rate
            mask2 = torch.bernoulli(
                torch.ones(4 * hidden_size, hidden_size, dtype=torch.float) * dropout_rate) / dropout_rate
        elif self.train_dropout_type == 2:
            # print('type 2: ')
            para = torch.bernoulli(
                torch.ones(4 * hidden_size, self.input_size, dtype=torch.float) * dropout_rate) / dropout_rate
            mask1 = para
            mask2 = para.expand(-1, hidden_size)
        elif self.train_dropout_type == 3:
            # print('type 3: ')
            p = math.sqrt((1 - dropout_rate) / dropout_rate)
            mask1 = torch.normal(1, torch.ones(4 * hidden_size, self.input_size, dtype=torch.float) * p)
            mask2 = torch.normal(1, torch.ones(4 * hidden_size, hidden_size, dtype=torch.float) * p)
        elif self.train_dropout_type == 4:
            # print('type 4: ')
            p = math.sqrt((1 - dropout_rate) / dropout_rate)
            para = torch.normal(1, torch.ones(4 * hidden_size, self.input_size, dtype=torch.float) * p)
            mask1 = para
            mask2 = para.expand(-1, hidden_size)
        else:
            print("Please select the correct DROPOUT_TYPE: 1-4")
        mask = (mask1.to(device), mask2.to(device))

        sequence_length = input.size(1)
        predict_length = sequence_length - step_look_back
        for i in range(input.size(1)):
            if i <= step_look_back - 1:
                h_t, c_t = self.lstm.forward_with_mask(input[:, i, :], mask, (h_t, c_t))
                output = self.linear(h_t)
                outputs.append(output)
            else:
                h_t, c_t = self.lstm.forward_with_mask(outputs[i - 1], mask, (h_t, c_t))
                output = self.linear(h_t)
                outputs.append(output)

        outputs = torch.stack(outputs[step_look_back:], 1).squeeze(2)
        return outputs

    def forward_test_with_past(self, input, step_look_back, hidden_size, dropout_rate, dropout_type):
        outputs = []
        device = input.device
        h_t = torch.zeros(input.size(0), self.input_size, dtype=torch.float, device=device)
        c_t = torch.zeros(input.size(0), self.input_size, dtype=torch.float, device=device)

        if dropout_type == 1:
            # print('type 1: ')
            mask1 = torch.bernoulli(
                torch.ones(4 * hidden_size, self.input_size, dtype=torch.float) * dropout_rate) / dropout_rate
            mask2 = torch.bernoulli(
                torch.ones(4 * hidden_size, hidden_size, dtype=torch.float) * dropout_rate) / dropout_rate
        elif dropout_type == 2:
            # print('type 2: ')
            para = torch.bernoulli(
                torch.ones(4 * hidden_size, self.input_size, dtype=torch.float) * dropout_rate) / dropout_rate
            mask1 = para
            mask2 = para.expand(-1, hidden_size)
        elif dropout_type == 3:
            # print('type 3: ')
            p = math.sqrt((1 - dropout_rate) / dropout_rate)
            mask1 = torch.normal(1, torch.ones(4 * hidden_size, self.input_size, dtype=torch.float) * p)
            mask2 = torch.normal(1, torch.ones(4 * hidden_size, hidden_size, dtype=torch.float) * p)
        elif dropout_type == 4:
            # print('type 4: ')
            p = math.sqrt((1 - dropout_rate) / dropout_rate)
            para = torch.normal(1, torch.ones(4 * hidden_size, self.input_size, dtype=torch.float) * p)
            mask1 = para
            mask2 = para.expand(-1, hidden_size)
        else:
            print("Please select the correct DROPOUT_TYPE: 1-4")
        mask = (mask1.to(device), mask2.to(device))

        sequence_length = input.size(1)
        predict_length = sequence_length - step_look_back
        for i in range(input.size(1)):
            if i <= step_look_back - 1:
                h_t, c_t = self.lstm.forward_with_mask(input[:, i, :], mask, (h_t, c_t))
                output = self.linear(h_t)
                outputs.append(output)
            else:
                h_t, c_t = self.lstm.forward_with_mask(outputs[i - 1], mask, (h_t, c_t))
                output = self.linear(h_t)
                outputs.append(output)

        outputs = torch.stack(outputs[step_look_back:], 1).squeeze(2)
        return outputs
# STL formula for checking CGM: 70<CGM<180
def requirement_func_always_BG_in_range(signal, trace_len, conf, lower_BG=70, upper_BG=180, func='monitor'):
    # signal: CGM trace, keep BG in range
    # G[0,t](CGM > lower_BG & CGM < upper_BG)
    # STL: G[0,10](signal>lower_BG) and (signal<upper_BG)
    # convert to:
    # G[0,10] (signal>lower_BG) and neg(signal>upper_BG)
    threshold_1 = lower_BG
    threshold_2 = upper_BG
    varphi_1 = (("mu", signal), [threshold_1, conf])
    varphi_2 = ((("neg", 0), (("mu", signal), [threshold_2, conf])))
    varphi_3 = (("always", (0, trace_len - 1)), (("and", 0), (varphi_1, varphi_2)))

    varphi_1_1 = (("mu", signal), threshold_1)
    varphi_2_1 = ((("neg", 0), (("mu", signal), threshold_2)))
    varphi_3_1 = (("always", (0, trace_len - 1)), (("and", 0), (varphi_1_1, varphi_2_1)))
    if func == 'monitor':
        return ustl.umonitor(varphi_3, 0)
    else:
        return (varphi_3_1, 0)
def mkdir(path):
    folder = os.path.exists(path)
    if not folder:
        os.makedirs(path)
        print('New folder ok.')
    else:
        print('There is this folder')

    return
def get_ppf(p: float):
    return norm.ppf(p)  # get the x value for certain confidence level p
def normalconf(mean, sigma, conf):
    # calculate upper and lower bound using given mean, std, and conf
    p = 1 - (1 - conf) / 2
    lower = mean - get_ppf(p) * sigma
    upper = mean + get_ppf(p) * sigma
    return (lower, upper)
# get upper and lower bound for predicted flowpipe
def get_upper_lower_bound_flowpipe(mean, sigma, conf):
    # calculate upper and lower bound using given mean, std, and conf
    p = 1 - (1 - conf) / 2
    lower = mean - norm.ppf(p) * sigma  # norm.ppf(p):get the x value for certain confidence level p
    upper = mean + norm.ppf(p) * sigma
    return (lower, upper)
############################################



def risk_diff(BG_last_hour):
    #print('func risk_diff.')
    if len(BG_last_hour) < 2:
        return 0
    else:
        _, _, risk_current = risk_index([BG_last_hour[-1]], 1)
        _, _, risk_prev = risk_index([BG_last_hour[-2]], 1)
        return risk_prev - risk_current


class T1DSimEnv(object):
    def __init__(self, patient, sensor, pump, scenario):
        self.patient = patient
        self.sensor = sensor
        self.pump = pump
        self.scenario = scenario
        self._reset()

    @property
    def time(self):
        return self.scenario.start_time + timedelta(minutes=int(self.patient.t))

    def mini_step(self, action):
        # current action
        patient_action = self.scenario.get_action(self.time)
        basal = self.pump.basal(action.basal)
        bolus = self.pump.bolus(action.bolus)
        # print('action in simulator: ', action, action.basal, action.bolus)
        # print('basal in simglucose env: ',basal, ' bolus: ', bolus)
        insulin = basal + bolus
        CHO = patient_action.meal
        patient_mdl_act = Action(insulin=insulin, CHO=CHO)

        # State update
        #print('patient_mdl_act: ', patient_mdl_act)
        self.patient.step(patient_mdl_act)

        # next observation
        BG = self.patient.observation.Gsub
        CGM = self.sensor.measure(self.patient)
        # print('BG in simglucose env: ', BG, CGM)

        return CHO, insulin, BG, CGM

    def get_past_trace_0(self):
        #selected_feature_col = ['hour', 'minute', 'lbgi', 'hbgi', 'risk', 'observation_CGM', 'observation_CHO','observation_insulin']
        trace_df = pd.DataFrame(columns=self.selected_feature_col)
        dict = {}
        for i in range(len(self.insulin_hist)):
            dict['hour'] = self.time_hist[i].hour
            dict['minute'] = self.time_hist[i].minute
            dict['lbgi'] = self.LBGI_hist[i]
            dict['hbgi'] = self.HBGI_hist[i]
            dict['risk'] = self.risk_hist[i]
            dict['observation_CGM'] = self.CGM_hist[i]
            dict['observation_CHO'] = self.CHO_hist[i]
            dict['observation_insulin'] = self.insulin_hist[i]
            #print('dict: ', dict)
            trace_df = trace_df.append(dict, ignore_index=True)

        return trace_df

    def get_past_trace(self):
        return self.trace_df

    def renew_past_trace_df(self):
        dict = {}
        dict['hour'] = self.time_hist[-1].hour
        dict['minute'] = self.time_hist[-1].minute
        dict['lbgi'] = self.LBGI_hist[-1]
        dict['hbgi'] = self.HBGI_hist[-1]
        dict['risk'] = self.risk_hist[-1]
        dict['observation_CGM'] = self.CGM_hist[-1]
        dict['observation_CHO'] = self.CHO_hist[-1]
        dict['observation_insulin'] = self.insulin_hist[-1][0]
        self.trace_df = self.trace_df.append(dict, ignore_index=True)

        return

    def predict_with_lstm_with_dropout(self, dataset_loader, lstm_model, predict_length, hidden_size,
                                       N_MC, step_look_back, dropout_rate, dropout_type, requirement_func, mean_df,
                                       std_df, conf):
        # evaluate the trained model with dataset
        lstm_model.eval()
        batch_len = 1
        with torch.no_grad():
            for batch_idx, datasample in enumerate(dataset_loader):  # tqdm(enumerate(test_loader)):
                data, target0 = datasample[0], datasample[1]
                target = []
                output = torch.zeros(N_MC, batch_len, predict_length, hidden_size)
                # apply dropout and loop N_MC times to get a series of predicted traces
                new_mean_df = mean_df.reset_index(drop=True)
                new_std_df = std_df.reset_index(drop=True)
                for i in range(N_MC):
                    output[i] = (lstm_model.forward_test_with_past(data, step_look_back, hidden_size, dropout_rate,
                                                                   dropout_type)).cpu()
                    # change predictions back to original scale
                    for feature_index in range(output[i].shape[2]):
                        output[i][:, :, feature_index] = (
                                output[i][:, :, feature_index] * new_std_df.loc[feature_index] + new_mean_df.loc[
                            feature_index]).cpu()
                output_CGM_mean = output.mean(dim=0)[:, :, -3]
                output_CGM_std = output.std(dim=0)[:, :, -3]
                trace_CGM = torch.stack((output_CGM_mean, output_CGM_std), dim=-1)
                # record mean and std value for each sample after applying dropout and loop N_MC times
                for b in range(batch_len):
                    # get rho interval for predictions with STL-U
                    rho_set_CGM = requirement_func(trace_CGM[b, :, :], predict_length - 1, conf=conf, lower_BG=70,
                                                   upper_BG=180, func='monitor')
            return output_CGM_mean.squeeze(0), output_CGM_std.squeeze(0), rho_set_CGM

    def generate_test_loader_for_prediction(self, trace_df, selected_feature_col, mean_df, std_df, predict_length):
        patient_trace_selected_df = pd.DataFrame(trace_df, columns=selected_feature_col)
        past_df_x = patient_trace_selected_df[-predict_length:]
        past_df_y = patient_trace_selected_df[-predict_length - 1:-1]
        # standardlize
        new_mean_df = mean_df
        new_std_df = std_df
        for feature in selected_feature_col:
            a_x = past_df_x[feature] - new_mean_df.loc[feature]
            b_x = a_x / new_std_df.loc[feature]
            a_y = past_df_x[feature] - new_mean_df.loc[feature]
            b_y = a_x / new_std_df.loc[feature]
            past_df_x[feature] = b_x
            past_df_y[feature] = b_y
        x = np.array(past_df_x).astype(float)
        y = np.array(past_df_y).astype(float)
        x = np.concatenate((x, np.zeros((predict_length, len(selected_feature_col)))), axis=0).astype(float)
        y = np.concatenate((y, np.zeros((predict_length, len(selected_feature_col)))), axis=0).astype(float)
        dataX = Variable(torch.from_numpy(x))
        dataY = Variable(torch.from_numpy(y))
        dataX = dataX.unsqueeze(0)
        dataY = dataY.unsqueeze(0)
        testX = Variable(torch.Tensor(np.array(dataX)))
        testY = Variable(torch.Tensor(np.array(dataY)))
        test_set = torch.utils.data.TensorDataset(testX, testY)
        test_loader = torch.utils.data.DataLoader(test_set, batch_size=1, num_workers=0, shuffle=False)
        return test_loader

    #@profile(precision=4,stream=open("/home/cpsgroup/Counterfactual_Explanation/diabetic_example/results/memory_profiler_env_step.log","w+"))
    def step(self, action, reward_fun=risk_diff):
        '''
        action is a namedtuple with keys: basal, bolus
        '''

        CHO = 0.0
        insulin = 0.0
        BG = 0.0
        CGM = 0.0

        for _ in range(int(self.sample_time)):
            # Compute moving average as the sample measurements
            # time_1 = time.perf_counter()
            tmp_CHO, tmp_insulin, tmp_BG, tmp_CGM = self.mini_step(action)
            # time_2 = time.perf_counter()
            # print('Time of Mini step: ', time_2 - time_1)
            CHO += tmp_CHO / self.sample_time
            insulin += tmp_insulin / self.sample_time
            BG += tmp_BG / self.sample_time
            CGM += tmp_CGM / self.sample_time

        # Compute risk index
        insulin = insulin.item()
        horizon = 1
        LBGI, HBGI, risk = risk_index([BG], horizon)

        # Record current action
        self.CHO_hist.append(CHO)
        self.insulin_hist.append(insulin)

        # Record next observation
        self.time_hist.append(self.time)
        self.BG_hist.append(BG)
        self.CGM_hist.append(CGM)
        self.risk_hist.append(risk)
        self.LBGI_hist.append(LBGI)
        self.HBGI_hist.append(HBGI)
        if self.if_stlu==1:
            self.renew_past_trace_df()

        # Compute reward, and decide whether game is over
        window_size = int(60 / self.sample_time)
        BG_last_hour = self.CGM_hist[-window_size:]
        insulin_total_past = sum(self.insulin_hist[-window_size*8:]) if len(self.insulin_hist)>(window_size*8) else sum(self.insulin_hist[:])
        #print('insulin_total_past: ', insulin_total_past)
        reward = reward_fun(BG_last_hour)
        #done = len(self.time_hist)>=3400 #BG < 70 or BG > 350
        done = BG < 40 or BG > 350
        #print('cal ROC: ', self.CGM_hist[-1], self.CGM_hist[-2], self.sample_time)
        ROC = (self.CGM_hist[-1] - self.CGM_hist[-2])/self.sample_time # CGM_rate_of_change
        #print('Insulin', insulin[0], type(insulin[0]))
        #obs = Observation(CGM=CGM, CHO=CHO, ROC=ROC, insulin=insulin[0])
        if self.if_stlu==1:  # use stlu monitor result in the state
            # this part is to add the monitor result of stlu (rho interval) to the observation
            # TODO: get past trace of this patient
            past_trace_df = self.get_past_trace()
            #print('past_trace_df: ', past_trace_df)
            if len(past_trace_df)>self.step_look_back: # if the past trace is long enough for prediction
                #print('use prediction')
                # TODO: use lstm to predict with past trace
                trace_loader = self.generate_test_loader_for_prediction(past_trace_df, self.selected_feature_col, self.mean_df, self.std_df, self.predict_length)
                # TODO: send prediction to stlu to get rho interval
                output_CGM_mean, output_CGM_std, rho_set_CGM = self.predict_with_lstm_with_dropout(
                                                                                trace_loader,
                                                                                self.lstm_model,
                                                                                self.predict_length,
                                                                                self.hidden_size, self.N_MC,
                                                                                self.step_look_back,
                                                                                self.dropout_rate,
                                                                                self.dropout_type,
                                                                                self.requirement_func_always_BG_in_range,
                                                                                self.mean_df, self.std_df,
                                                                                self.conf)

                output_CGM_low, output_CGM_up = get_upper_lower_bound_flowpipe(output_CGM_mean, output_CGM_std, self.conf)
                rho_low, rho_up = rho_set_CGM[0], rho_set_CGM[1]
                # TODO: add rho interval to observation
                obs = Observation(CGM=CGM, CHO=CHO, ROC=ROC, insulin=insulin, rho_low=rho_low, rho_up=rho_up)
            else:
                obs = Observation(CGM=CGM, CHO=CHO, ROC=ROC, insulin=insulin, rho_low=-0.0, rho_up=0.0)
        else: # not use stlu monitor result in the state
            obs = Observation(CGM=CGM, CHO=CHO, ROC=ROC, insulin=insulin)
        #print('obs this step: ', obs)


        return Step(observation=obs,
                    reward=reward,
                    done=done,
                    sample_time=self.sample_time,
                    patient_name=self.patient.name,
                    meal=CHO,
                    patient_state=self.patient.state,
                    time=self.time,
                    bg=BG,
                    lbgi=LBGI,
                    hbgi=HBGI,
                    risk=risk)

    def _reset(self):
        # print('_reset in env.py.')
        self.sample_time = self.sensor.sample_time
        self.viewer = None

        BG = self.patient.observation.Gsub
        # CHO = self.patient.observation.CHO
        horizon = 1
        LBGI, HBGI, risk = risk_index([BG], horizon)
        CGM = self.sensor.measure(self.patient)
        self.time_hist = [self.scenario.start_time]
        self.BG_hist = [BG]
        self.CGM_hist = [CGM]
        self.risk_hist = [risk]
        self.LBGI_hist = [LBGI]
        self.HBGI_hist = [HBGI]
        self.CHO_hist = []
        self.insulin_hist = []

        self.if_stlu = 0 # if using stlu monitor results in the state
        #print('self.if_stlu: ', self.if_stlu)

    #@profile(precision=4,stream=open("/home/cpsgroup/Counterfactual_Explanation/diabetic_example/results/memory_profiler_env_reset.log","w+"))
    def reset(self, **kwargs):
        #print('reset in env.py.')
        dict = kwargs
        if (not ('determine' in dict.keys())) or dict['determine'] == 0:  # if do not need to use deterministic reset.
        #if dict['determine']==0:
            patient_kwargs = {}
            sensor_kwargs = {}
            scenario_kwargs = {}
            self.patient.reset(**patient_kwargs)
            self.sensor.reset(**sensor_kwargs)
            self.pump.reset()
            self.scenario.reset(**scenario_kwargs)
            self._reset()
            CGM = self.sensor.measure(self.patient)
            CHO = self.patient._last_action.CHO
            ROC = (self.CGM_hist[-1] - self.CGM_hist[-2]) / self.sample_time if len(self.CGM_hist) >= 2 else 0  # CGM_rate_of_change
            #obs = Observation(CGM=CGM, CHO=CHO, ROC=ROC, insulin=self.patient._last_action.insulin) # this is set later in if self.if_stlu condition.
        elif dict['determine'] == 1:  # if need to use deterministic reset to set patient state to some specific values
            patient_kwargs = dict['patient_state']
            sensor_kwargs = dict['sensor_state']
            scenario_kwargs = dict['scenario_state']
            scenario = scenario_kwargs['scenario']
            #print('scenario: ', scenario)
            scenario_start_time = dict['scenario_state']['start_time']
            # scenario_time_list = scenario_kwargs['scenario']['meal']['time']
            # scenario_meal_amount_list = scenario_kwargs['scenario']['meal']['amount']
            # custom_scenario_list = []
            # for i in range(0, len(scenario_time_list)):
            #     custom_scenario_list.append((scenario_time_list[i], scenario_meal_amount_list[i]))
            self.patient.reset(**patient_kwargs)
            self.sensor.reset(**sensor_kwargs)
            self.pump.reset()
            #self.scenario.reset(**scenario_kwargs)
            #scenario_start_time = self.scenario.start_time
            costum_scenario = CustomScenario(start_time=scenario_start_time, scenario=scenario)
            #self.scenario.reset(**scenario_kwargs)
            self.scenario  = costum_scenario
            #print('reset as costum_scenario: ', self.scenario.start_time, self.scenario.scenario)
            self._reset()
            CGM = self.sensor.measure(self.patient, dict['CGM'], determain=1)
            CHO = self.patient._last_action.CHO
            ROC = dict['ROC'] # CGM_rate_of_change
            #obs = Observation(CGM=CGM, CHO=CHO, ROC=ROC, insulin=self.patient._last_action.insulin)

        # set necessary parts for using stlu and lstm
        if self.if_stlu==1:
            #print('Reset stlu and lstm params.')
            self.selected_feature_col = ['hour', 'minute', 'lbgi', 'hbgi', 'risk', 'observation_CGM', 'observation_CHO','observation_insulin']
            self.trace_df = pd.DataFrame(columns=self.selected_feature_col)
            self.requirement_func_always_BG_in_range = requirement_func_always_BG_in_range
            num_feature = len(self.selected_feature_col)
            num_classes = num_feature
            self.input_size = num_feature
            self.hidden_size = num_feature
            self.input_size = num_feature
            self.num_layers = 1
            self.step_look_back = 10
            self.train_dropout_type = 4
            self.predict_length = 10
            self.N_MC = 30
            self.conf = 0.95
            # adult model
            adult_lstm_path = r'D:\ShuyangDongDocument\UVA\UVA-Research\Project\AAAI\RL_case_study\lstm_s1_with_dropout_lr_0.01_dt_4_dr_0.9_e_50_3_m_8_f_adult_patient_state_dict.pt'
            # child model
            child_lstm_path = r'D:\ShuyangDongDocument\UVA\UVA-Research\Project\AAAI\RL_case_study\lstm_s1_with_dropout_lr_0.01_dt_4_dr_0.9_e_50_3_m_8_f_child_patient_state_dict.pt'
            # adolescent model
            adolescent_lstm_path = r'D:\ShuyangDongDocument\UVA\UVA-Research\Project\AAAI\RL_case_study\lstm_s1_with_dropout_lr_0.001_dt_4_dr_0.9_e_50_3_m_8_f_adolescent_patient_state_dict.pt'
            lstm_path_dict = {'adult': adult_lstm_path, 'child': child_lstm_path, 'adolescent': adolescent_lstm_path}
            dropout_rate_dict = {'adult': 0.8, 'child': 0.9, 'adolescent': 0.9}
            dropout_type_dict = {'adult': 2, 'child': 3, 'adolescent': 2}

            patient_type = self.patient.name[:-4]
            #print('patient_type: ', patient_type)
            lstm_path = lstm_path_dict[patient_type]
            self.lstm_model = LSTM(num_classes, self.input_size, self.hidden_size, self.num_layers, self.step_look_back, self.train_dropout_type)
            self.lstm_model.load_state_dict(torch.load(lstm_path, map_location=torch.device('cpu')))
            self.lstm_model.eval()
            all_mean_value_file_path = r'D:\ShuyangDongDocument\UVA\UVA-Research\Project\AAAI\RL_case_study\all_mean_value.csv'
            all_std_value_file_path = r'D:\ShuyangDongDocument\UVA\UVA-Research\Project\AAAI\RL_case_study\all_std_value.csv'
            all_mean_df = pd.read_csv(all_mean_value_file_path, index_col=0)
            all_std_df = pd.read_csv(all_std_value_file_path, index_col=0)
            self.dropout_rate = dropout_rate_dict[patient_type]
            self.dropout_type = dropout_type_dict[patient_type]
            self.mean_df = all_mean_df[patient_type]
            self.std_df = all_std_df[patient_type]

            obs = Observation(CGM=CGM, CHO=CHO, ROC=ROC, insulin=self.patient._last_action.insulin, rho_low=-0.0, rho_up=0.0)
        else:
            obs = Observation(CGM=CGM, CHO=CHO, ROC=ROC, insulin=self.patient._last_action.insulin)

            ##################################################################

        return Step(observation=obs,
                    reward=0,
                    done=False,
                    sample_time=self.sample_time,
                    patient_name=self.patient.name,
                    meal=0,
                    patient_state=self.patient.state,
                    time=self.time,
                    bg=self.BG_hist[0],
                    lbgi=self.LBGI_hist[0],
                    hbgi=self.HBGI_hist[0],
                    risk=self.risk_hist[0])

    def render(self, close=False):
        if close:
            if self.viewer is not None:
                self.viewer.close()
                self.viewer = None
            return

        if self.viewer is None:
            self.viewer = Viewer(self.scenario.start_time, self.patient.name)

        self.viewer.render(self.show_history())

    def show_history(self):
        df = pd.DataFrame()
        df['Time'] = pd.Series(self.time_hist)
        df['BG'] = pd.Series(self.BG_hist)
        df['CGM'] = pd.Series(self.CGM_hist)
        df['CHO'] = pd.Series(self.CHO_hist)
        df['insulin'] = pd.Series(self.insulin_hist)
        df['LBGI'] = pd.Series(self.LBGI_hist)
        df['HBGI'] = pd.Series(self.HBGI_hist)
        df['Risk'] = pd.Series(self.risk_hist)
        df = df.set_index('Time')
        return df
